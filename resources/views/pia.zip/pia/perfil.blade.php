<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
              <img width="75" height="100" class="thumb-image" src="/Perfil/3/perfil_3.jpg" align="left">
   	  		 <h1 align="center">EDITANDO PIA</h1>
   	  		 <h4>NOME: SDASDASDASDASDASDASDASDASDASDASDASDS</h4>
		</div>
	</div>
</div>